from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import BusinessPlan
import json
import openpyxl


def get_user_grade(request):
    grade = request.headers.get('X-Grade-Id')
    if grade:
        return int(grade)
    return 0


@csrf_exempt
def get_all(request):
    section_id = request.GET.get('section_id')
    is_superuser = request.GET.get('is_superuser', 'false').lower() == 'true'
    grade_id = request.GET.get('grade_id', '0')
    admin_grades = [9, 10, 11]

    # Superuser ya grade 9/10/11 — sab dikhao
    if is_superuser or int(grade_id) in admin_grades:
        plans = BusinessPlan.objects.all().values()
    elif section_id and section_id != '0':
        try:
            from sections.models import Sections
            section = Sections.objects.get(id=int(section_id))
            plans = BusinessPlan.objects.filter(
                department__icontains=section.name
            ).values()
        except Exception:
            plans = BusinessPlan.objects.all().values()
    else:
        plans = BusinessPlan.objects.all().values()

    return JsonResponse(list(plans), safe=False)


@csrf_exempt
def upload_excel(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'POST only'}, status=405)

    excel_file = request.FILES.get('file')
    if not excel_file:
        return JsonResponse({'error': 'No file uploaded'}, status=400)

    try:
        wb = openpyxl.load_workbook(excel_file)
        ws = wb.active
        created = 0
        erpid = int(request.POST.get('erpid', 0))
        section_id = request.POST.get('section_id', None)
        grade = get_user_grade(request)

        for row in ws.iter_rows(min_row=2, values_only=True):
            if not row[0]:
                continue
            sr      = str(row[0]).strip()
            dept    = str(row[1] or '').strip()
            task    = str(row[2] or '').strip()
            start   = row[3]
            end     = row[4]
            lead    = str(row[5] or '').strip()
            support = str(row[6] or '').strip()
            dep     = str(row[7] or '').strip()
            deliv   = str(row[8] or '').strip()
            level   = int(row[9] or 0)
            parent  = str(row[10] or '').strip() if len(row) > 10 and row[10] else None

            if BusinessPlan.objects.filter(sr_number=sr).exists():
                continue

            BusinessPlan.objects.create(
                sr_number=sr,
                parent_sr=parent or None,
                level=level,
                department=dept,
                # section_id=int(section_id) if section_id else None,
                task=task,
                start_date=start if start else None,
                end_date=end if end else None,
                lead_team=lead,
                support_team=support,
                dependencies=dep,
                deliverables=deliv,
                completion_pct=0,
                created_by=erpid,
                uploaded_by_grade=grade
            )
            created += 1

        return JsonResponse({'success': True, 'rows_created': created})

    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)


@csrf_exempt
def add_row(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'POST only'}, status=405)
    try:
        data = json.loads(request.body)
        BusinessPlan.objects.create(
            sr_number=data.get('sr_number'),
            parent_sr=data.get('parent_sr') or None,
            level=data.get('level', 0),
            department=data.get('department', ''),
            # section_id=data.get('section_id') or None,
            task=data.get('task', ''),
            start_date=data.get('start_date') or None,
            end_date=data.get('end_date') or None,
            lead_team=data.get('lead_team', ''),
            support_team=data.get('support_team', ''),
            dependencies=data.get('dependencies', ''),
            deliverables=data.get('deliverables', ''),
            completion_pct=0,
            created_by=data.get('created_by', 0),
            uploaded_by_grade=data.get('uploaded_by_grade', 0),
        )
        return JsonResponse({'success': True})
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

@csrf_exempt
def delete_all(request):
    if request.method != 'DELETE':
        return JsonResponse({'error': 'DELETE only'}, status=405)
    try:
        # Sab delete karo — koi filter nahi
        BusinessPlan.objects.all().delete()
        return JsonResponse({'success': True})
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)
        
@csrf_exempt
def update_row(request, pk):
    if request.method != 'PUT':
        return JsonResponse({'error': 'PUT only'}, status=405)
    try:
        data = json.loads(request.body)
        bp = BusinessPlan.objects.get(pk=pk)
        bp.task           = data.get('task', bp.task)
        bp.start_date     = data.get('start_date') or bp.start_date
        bp.end_date       = data.get('end_date') or bp.end_date
        bp.lead_team      = data.get('lead_team', bp.lead_team)
        bp.support_team   = data.get('support_team', bp.support_team)
        bp.dependencies   = data.get('dependencies', bp.dependencies)
        bp.deliverables   = data.get('deliverables', bp.deliverables)
        bp.completion_pct = data.get('completion_pct', bp.completion_pct)
        bp.save()
        return JsonResponse({'success': True})
    except BusinessPlan.DoesNotExist:
        return JsonResponse({'error': 'Not found'}, status=404)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)


@csrf_exempt
def delete_row(request, pk):
    if request.method != 'DELETE':
        return JsonResponse({'error': 'DELETE only'}, status=405)
    try:
        BusinessPlan.objects.get(pk=pk).delete()
        return JsonResponse({'success': True})
    except BusinessPlan.DoesNotExist:
        return JsonResponse({'error': 'Not found'}, status=404)